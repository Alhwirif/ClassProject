	package assignment2;
	
	import LabProject.*
	
	
	
	
	public class Session { 
		
	
	
		public static void main(String [] args) {
		int ID;
		
		
		User user1;
		Displayer print;
		
	    print.printScreen();
	    print.clearScreen();
	    print.printDisclaim();
	    print.includeSearchResults();
		
		
	}
		
		
}
